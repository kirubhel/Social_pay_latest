package pkg

import (
	"fmt"

	"github.com/socialpay/socialpay/src/internal"
	"github.com/socialpay/socialpay/src/internal/txts"
)

// "fmt"

func Test() {
	fmt.Printf("asdasd %s %s", internal.TestInternal{}, txts.TestTxts{})
}
