package usecase

type Repo interface {
}
