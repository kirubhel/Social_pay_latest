package usecase

type Interactor interface {
	// Bank

	// Transaction
	// InitTransaction(
	// 	from uuid.UUID,
	// 	to []struct {
	// 		Account uuid.UUID
	// 		Ratio   float64
	// 		Amount  float64
	// 	},
	// 	medium entity.TransactionMedium,
	// 	txType entity.TransactionType,
	// 	amount float64,
	// )

	// GetUserTransactions(userId uuid.UUID) ([]entity.Transaction, error)

}
