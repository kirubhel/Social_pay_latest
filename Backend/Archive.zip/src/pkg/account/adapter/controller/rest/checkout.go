package rest

import "net/http"

func (controller Controller) getInitCheckout(w http.ResponseWriter, r *http.Request) {}

func (controller Controller) getProcessCheckout(w http.ResponseWriter, r *http.Request) {}
