package usecase

type Interactor interface {
	// Create Message
	// CreateMessage(from uuid.UUID, )
	// Update Message
	// Get Message by Id
	// Get Messages
	// Delete Message
}
