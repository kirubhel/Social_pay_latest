package usecase

type Interactor interface{}
