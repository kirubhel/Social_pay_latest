package usecase

type Usecase struct{}
