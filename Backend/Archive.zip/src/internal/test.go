package internal

type TestInternal struct {
}
