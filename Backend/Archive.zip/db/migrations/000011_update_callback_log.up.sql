ALTER TABLE webhook.callback_logs ADD reason TEXT;
