ALTER TABLE webhook.callback_logs DROP COLUMN reason;
