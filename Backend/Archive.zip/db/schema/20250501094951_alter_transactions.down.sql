ALTER TABLE public.transactions
ALTER COLUMN status TYPE VARCHAR(200);