
DROP TYPE transaction_status;